-- phpMyAdmin SQL Dump
-- version 4.0.4.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Feb 06, 2019 at 05:30 PM
-- Server version: 5.5.32
-- PHP Version: 5.4.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `bc`
--
CREATE DATABASE IF NOT EXISTS `bc` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `bc`;

-- --------------------------------------------------------

--
-- Table structure for table `cheat`
--

CREATE TABLE IF NOT EXISTS `cheat` (
  `cid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `no_of_people` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  `date` date NOT NULL,
  `duration` varchar(12) NOT NULL,
  `fine` int(11) NOT NULL,
  `next_date` date NOT NULL,
  PRIMARY KEY (`cid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `cheat`
--

INSERT INTO `cheat` (`cid`, `name`, `no_of_people`, `amount`, `date`, `duration`, `fine`, `next_date`) VALUES
(2, 'Aj Fund', 5, 100, '2019-01-31', '5', 20, '2019-02-10');

-- --------------------------------------------------------

--
-- Table structure for table `cheat_details`
--

CREATE TABLE IF NOT EXISTS `cheat_details` (
  `cd_id` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL,
  `cid` int(11) NOT NULL,
  PRIMARY KEY (`cd_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `cheat_details`
--

INSERT INTO `cheat_details` (`cd_id`, `pid`, `cid`) VALUES
(2, 2, 2),
(3, 3, 2);

-- --------------------------------------------------------

--
-- Table structure for table `chit_withdraw`
--

CREATE TABLE IF NOT EXISTS `chit_withdraw` (
  `cwdid` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL,
  `cid` int(11) NOT NULL,
  `dateofwd` date NOT NULL,
  PRIMARY KEY (`cwdid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

-- --------------------------------------------------------

--
-- Table structure for table `loginc`
--

CREATE TABLE IF NOT EXISTS `loginc` (
  `login_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `mobile` varchar(12) NOT NULL,
  `address` varchar(100) NOT NULL,
  `uname` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `role` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL,
  PRIMARY KEY (`login_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `loginc`
--

INSERT INTO `loginc` (`login_id`, `name`, `mobile`, `address`, `uname`, `password`, `role`, `status`) VALUES
(1, 'ajaykumar chhalla', '98609402031', 'prasad', 'aj', 'aj123', 'admin', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `people`
--

CREATE TABLE IF NOT EXISTS `people` (
  `pid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `mobile` varchar(12) NOT NULL,
  `address` varchar(100) NOT NULL,
  `adharno` varchar(12) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`pid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `people`
--

INSERT INTO `people` (`pid`, `name`, `mobile`, `address`, `adharno`, `date`) VALUES
(2, 'Ajaykumar', '8551977703', 'aravali', '123456789', '2019-01-31'),
(3, 'Dheeraj Soni ', '8551977703', 'aravali', '15935746', '2019-01-31');

-- --------------------------------------------------------

--
-- Table structure for table `transaction`
--

CREATE TABLE IF NOT EXISTS `transaction` (
  `tid` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL,
  `cid` int(11) NOT NULL,
  `tran_type` varchar(100) NOT NULL,
  `amount` int(11) NOT NULL,
  `date` date NOT NULL,
  `entry_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`tid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=25 ;

--
-- Dumping data for table `transaction`
--

INSERT INTO `transaction` (`tid`, `pid`, `cid`, `tran_type`, `amount`, `date`, `entry_date`, `status`) VALUES
(23, 2, 2, 'fine', 20, '2019-02-05', '2019-02-06 16:23:17', 0),
(24, 3, 2, 'fine', 20, '2019-02-05', '2019-02-06 16:23:17', 0);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
