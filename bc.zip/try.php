<?php 

$date = "2019-01-22";
date('Y-m-d', strtotime("+7 day", strtotime($date)));

date_default_timezone_set('Asia/Kolkata');
 $date1 = date('Y-m-d');

if($date1 > $date)
{
	echo "hii";
}

?>