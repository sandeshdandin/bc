<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<title>Chit Fund</title>
	<meta content='width=device-width, initial-scale=1.0, shrink-to-fit=no' name='viewport' />
	<link rel="icon" href="assets/img/icon.ico" type="image/x-icon"/>

	<!-- Fonts and icons -->
	<script src="assets/js/plugin/webfont/webfont.min.js"></script>
	<script>
		WebFont.load({
			google: {"families":["Lato:300,400,700,900"]},
			custom: {"families":["Flaticon", "Font Awesome 5 Solid", "Font Awesome 5 Regular", "Font Awesome 5 Brands", "simple-line-icons"], urls: ['assets/css/fonts.min.css']},
			active: function() {
				sessionStorage.fonts = true;
			}
		});
	</script>

	<!-- CSS Files -->
	<link rel="stylesheet" href="assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="assets/css/atlantis.min.css">

	<!-- CSS Just for demo purpose, don't include it in your project -->
	<link rel="stylesheet" href="assets/css/demo.css">
</head>
<?php

include "conn.php";
session_start();
if (!isset($_SESSION['UserId'])){
session_destroy();	
header('location:index.php');   
} 
$UId=$_SESSION['UserId'];

?>
<body>
	<div class="wrapper">
		<?php include("header.php"); ?>		

		<!-- Sidebar -->
		<?php include("sidebar.php"); ?>		
		<!-- End Sidebar -->

		<div class="main-panel">
			<div class="content">
				<div class="panel-header bg-primary-gradient">
					<div class="page-inner py-5">
						<div class="d-flex align-items-left align-items-md-center flex-column flex-md-row">
							<div>
								<?php 
								$chit_id = $_GET['id1'];
				
				$result=mysql_query("SELECT name,no_of_people FROM cheat where cid='$chit_id' ");
				$row = mysql_fetch_array($result);
				$chit_name = $row["name"];
								?>
								<h2 class="text-white pb-2 fw-bold">Add New Chit Holder to <font color="orange"><?php echo $chit_name;?></font></h2>
							</div>
						</div>
					</div>
				</div>
				<?php
				
				
				$no_of_people = $row["no_of_people"];
				
				if (isset($_POST['submit'])) {
					include "conn.php";
						
						$cname1=$_POST['cname'];
						$name1=$_POST['name'];
						$mobile=$_POST['mobile'];
						$address=$_POST['address'];
						$adhar=$_POST['adhar'];
						$date=$_POST['date'];
												
					mysql_query("INSERT INTO people(name,mobile,address,adharno,date)VALUES('$name1','$mobile','$address','$adhar','$date')");
					
					
				$result=mysql_query("SELECT pid FROM people where adharno='$adhar' ");
				$row = mysql_fetch_array($result);
				$pid1 = $row["pid"];
					
					mysql_query("INSERT INTO cheat_details(pid,cid)VALUES('$pid1','$chit_id')");
					
					echo "Chit Holder Added";
					
					echo "<script type='text/javascript'>";
					echo "window.location.href='totalchit1.php?id1=$chit_id' ";
					echo "</script>";
					}
				
				?>
				<div class="page-inner mt--5">
					<div class="row mt--2">
						<div class="col-md-12">
							<div class="card full-height">
								<div class="card-body">
								<div class="col-md-12 col-lg-12">
								<form action="" method="post">		
											<div class="form-group">
												<label for="email2">Chit Name</label>
												<input type="text" class="form-control" id="name" placeholder="Enter Name" name="cname" value="<?php echo  $chit_name;?>" readonly required="">						
											</div>
										
											<div class="form-group">
												<label for="email2">Name</label>
												<input type="text" class="form-control" id="name" placeholder="Enter Name" name="name" required="">
												
											</div>
											<div class="form-group">
												<label >Mobile</label>
												<input type="number" class="form-control" id="noofpeople" placeholder="Enter Mobile"name="mobile" required="">
											</div>
											<div class="form-group">
												<label for="password">Address</label>
												<input type="text" class="form-control" id="noofpeople" placeholder="Enter Address"name="address" required="">
											</div>
											<div class="form-group">
												<label for="password">Addhar Number</label>
												<input type="text" class="form-control" id="noofpeople" placeholder="Enter Adhar Number" required="" name="adhar">
											</div>
											<div class="form-group">
												<label for="password">Date</label>
												<input type="date" class="form-control" id="noofpeople" name="date" required="">
											</div>
											
											<div class="form-group">
												
												<input type="submit" style="background-color: green; color: white" class="form-control" name="submit" value="Submit">
											</div>
										</form>
											
										</div>
									
								</div>
							</div>
						</div>
						
					</div>
	
				</div>
			</div>
			
		</div>
		
		<!-- Custom template | don't include it in your project! -->
	
		<!-- End Custom template -->
	</div>
	<!--   Core JS Files   -->
	<script src="assets/js/core/jquery.3.2.1.min.js"></script>
	<script src="assets/js/core/popper.min.js"></script>
	<script src="assets/js/core/bootstrap.min.js"></script>

	<!-- jQuery UI -->
	<script src="assets/js/plugin/jquery-ui-1.12.1.custom/jquery-ui.min.js"></script>
	<script src="assets/js/plugin/jquery-ui-touch-punch/jquery.ui.touch-punch.min.js"></script>

	<!-- jQuery Scrollbar -->
	<script src="assets/js/plugin/jquery-scrollbar/jquery.scrollbar.min.js"></script>


	<!-- Chart JS -->
	<script src="assets/js/plugin/chart.js/chart.min.js"></script>

	<!-- jQuery Sparkline -->
	<script src="assets/js/plugin/jquery.sparkline/jquery.sparkline.min.js"></script>

	<!-- Chart Circle -->
	<script src="assets/js/plugin/chart-circle/circles.min.js"></script>

	<!-- Datatables -->
	<script src="assets/js/plugin/datatables/datatables.min.js"></script>

	<!-- Bootstrap Notify -->
	

	<!-- jQuery Vector Maps -->
	<script src="assets/js/plugin/jqvmap/jquery.vmap.min.js"></script>
	<script src="assets/js/plugin/jqvmap/maps/jquery.vmap.world.js"></script>

	<!-- Sweet Alert -->
	<script src="assets/js/plugin/sweetalert/sweetalert.min.js"></script>

	<!-- Atlantis JS -->
	<script src="assets/js/atlantis.min.js"></script>

	<!-- Atlantis DEMO methods, don't include it in your project! -->
	<script src="assets/js/setting-demo.js"></script>
	<script src="assets/js/demo.js"></script>
	<script>
		Circles.create({
			id:'circles-1',
			radius:45,
			value:60,
			maxValue:100,
			width:7,
			text: 5,
			colors:['#f1f1f1', '#FF9E27'],
			duration:400,
			wrpClass:'circles-wrp',
			textClass:'circles-text',
			styleWrapper:true,
			styleText:true
		})

		Circles.create({
			id:'circles-2',
			radius:45,
			value:70,
			maxValue:100,
			width:7,
			text: 36,
			colors:['#f1f1f1', '#2BB930'],
			duration:400,
			wrpClass:'circles-wrp',
			textClass:'circles-text',
			styleWrapper:true,
			styleText:true
		})

		Circles.create({
			id:'circles-3',
			radius:45,
			value:40,
			maxValue:100,
			width:7,
			text: 12,
			colors:['#f1f1f1', '#F25961'],
			duration:400,
			wrpClass:'circles-wrp',
			textClass:'circles-text',
			styleWrapper:true,
			styleText:true
		})

		var totalIncomeChart = document.getElementById('totalIncomeChart').getContext('2d');

		var mytotalIncomeChart = new Chart(totalIncomeChart, {
			type: 'bar',
			data: {
				labels: ["S", "M", "T", "W", "T", "F", "S", "S", "M", "T"],
				datasets : [{
					label: "Total Income",
					backgroundColor: '#ff9e27',
					borderColor: 'rgb(23, 125, 255)',
					data: [6, 4, 9, 5, 4, 6, 4, 3, 8, 10],
				}],
			},
			options: {
				responsive: true,
				maintainAspectRatio: false,
				legend: {
					display: false,
				},
				scales: {
					yAxes: [{
						ticks: {
							display: false //this will remove only the label
						},
						gridLines : {
							drawBorder: false,
							display : false
						}
					}],
					xAxes : [ {
						gridLines : {
							drawBorder: false,
							display : false
						}
					}]
				},
			}
		});

		$('#lineChart').sparkline([105,103,123,100,95,105,115], {
			type: 'line',
			height: '70',
			width: '100%',
			lineWidth: '2',
			lineColor: '#ffa534',
			fillColor: 'rgba(255, 165, 52, .14)'
		});
	</script>
	
	<script >
		$(document).ready(function() {
			$('#basic-datatables').DataTable({
			});

			$('#multi-filter-select').DataTable( {
				"pageLength": 5,
				initComplete: function () {
					this.api().columns().every( function () {
						var column = this;
						var select = $('<select class="form-control"><option value=""></option></select>')
						.appendTo( $(column.footer()).empty() )
						.on( 'change', function () {
							var val = $.fn.dataTable.util.escapeRegex(
								$(this).val()
								);

							column
							.search( val ? '^'+val+'$' : '', true, false )
							.draw();
						} );

						column.data().unique().sort().each( function ( d, j ) {
							select.append( '<option value="'+d+'">'+d+'</option>' )
						} );
					} );
				}
			});

			// Add Row
			$('#add-row').DataTable({
				"pageLength": 5,
			});

			var action = '<td> <div class="form-button-action"> <button type="button" data-toggle="tooltip" title="" class="btn btn-link btn-primary btn-lg" data-original-title="Edit Task"> <i class="fa fa-edit"></i> </button> <button type="button" data-toggle="tooltip" title="" class="btn btn-link btn-danger" data-original-title="Remove"> <i class="fa fa-times"></i> </button> </div> </td>';

			$('#addRowButton').click(function() {
				$('#add-row').dataTable().fnAddData([
					$("#addName").val(),
					$("#addPosition").val(),
					$("#addOffice").val(),
					action
					]);
				$('#addRowModal').modal('hide');

			});
		});
	</script>
</body>
</html>