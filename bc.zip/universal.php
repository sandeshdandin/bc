<?php 
include "conn.php";


	date_default_timezone_set('Asia/Kolkata');
	$c_date = date('Y-m-d');

	$result =( "SELECT 	cid,next_date,duration,fine from cheat  ");
	$asdfg = mysql_query( $result, $con );
	while($row = mysql_fetch_array($asdfg, MYSQL_ASSOC))				
	{		
		//echo "<br>";
		 $cid1=$row['cid'];
		//echo "<br>";
		 $next_date1=$row['next_date'];
		//echo "<br>";
		 $duration1=$row['duration'];
		$fine1=$row['fine'];
		//echo "<br>";
		$previous_chit_date =  date('Y-m-d', strtotime("-$duration1 day", strtotime($next_date1)));
						
						if($c_date > $next_date1)
						{
							$result1 =( "SELECT pid from cheat_details where cid='$cid1'  ");
							$asdfg1 = mysql_query( $result1, $con );
							while($row2 = mysql_fetch_array($asdfg1, MYSQL_ASSOC))				
							{
								//echo "<br>";
								 $pid1 = $row2['pid'];			
								//echo "<br>";			
								
								$result30=mysql_query("SELECT COUNT(tid) as tid FROM transaction where pid='$pid1' and cid='$cid1' and date > '$previous_chit_date' and date < '$next_date1' and tran_type='cash' ");
								$row11 = mysql_fetch_array($result30);
								$abc = print_r($row11,true);
								 $abc;
								$count = mysql_num_rows($result30);
								$tid11 = $row11["tid"];
								if($tid11 == 0)
								{
							
									$result2=mysql_query("SELECT COUNT(tid) as tid FROM transaction where pid='$pid1' and cid='$cid1' and date > '$previous_chit_date' and date < '$next_date1' and tran_type='fine' ");
									$row1 = mysql_fetch_array($result2);
									$abc = print_r($row1,true);
									 $abc;
									$count = mysql_num_rows($result2);
									$tid = $row1["tid"];
									if($tid == 0)
									{
										$date = date('Y-m-d');
										mysql_query("INSERT INTO transaction(pid,cid,tran_type,amount,date)VALUES('$pid1', '$cid1','fine','$fine1','$next_date1')");
										//echo "Fine entry done";
									}
									else
									{
										//echo "fine already applieed";
									}

								 
								}
								
								
							}
							
							
							
						}
						
						

					}
		
	$result1 =( "SELECT cid,next_date,duration,fine from cheat  ");
	$asdfg1 = mysql_query( $result1, $con );
	while($row = mysql_fetch_array($asdfg1, MYSQL_ASSOC))				
	{	
		 $cid2 = $row['cid'];
		 $next_date2 = $row['next_date'];
		 $duration2=$row['duration'];
		 
		$nexttonextdate =  date('Y-m-d', strtotime("+$duration2 day", strtotime($next_date2)));

		if($c_date > $next_date1)
		{		
			$sql= "UPDATE cheat SET next_date='$nexttonextdate' WHERE cid='$cid2'";
			mysql_query($sql);

		}


	}
	

?>