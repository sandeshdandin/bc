<?php 
echo $date = date('Y-m-d');
?>