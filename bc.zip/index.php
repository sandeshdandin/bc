<!DOCTYPE html>
<html >
<head>
  <meta charset="UTF-8">
  <title>Chit Fund</title>
  
  
  <link rel='stylesheet prefetch' href='http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css'>

      <link rel="stylesheet" href="css/style.css">

  
</head>
 <?php
		 if (isset($_POST['submit'])) {
			include "conn.php";
			$name1=mysql_real_escape_string($_POST['name']);
			$password1=mysql_real_escape_string($_POST['password']);			
	
						$result = mysql_query("SELECT login_id,uname,password  FROM loginc WHERE uname='$name1' && password='$password1'   ");
						$row = mysql_fetch_array($result);
  						$count=mysql_num_rows($result);
  						if($count == 1)
                        {
							session_destroy();
							session_start();
							$_SESSION['UserId']= NULL;
                            $_SESSION['UserId']= $row['login_id'];     
							
							
							header("location:dashboard.php");  
													  
                        }
  						else
                        {
                        	 echo "<center><font color='red'>"."Username or Password Wrong. Try Again"."</font></center>";
                        }

			
		 }
	  ?>
<body>
  <div class="login-form">
     <h1>Chit Fund</h1> 
    <form action="" method="post">
     <div class="form-group ">
       <input type="text" class="form-control" placeholder="Username " id="UserName" name="name">
       <i class="fa fa-user"></i>
     </div>
     <div class="form-group log-status">
       <input type="password" class="form-control" placeholder="Password" id="Passwod" name="password">
       <i class="fa fa-lock"></i>
     </div>
      
     <button type="submit" name="submit" class="log-btn" >Log in</button>
     </form>
    
   </div>
  <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>

    <script src="js/index.js"></script>

</body>
</html>
